module JavaFxEmailClientCourse {

    requires javafx.controls;
    requires javafx.web;
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.base;
    requires java.sql;
    requires controlsfx;
    requires jasperreports;

    opens com.zhyar.controller;
    opens com.zhyar.view;
    opens com.zhyar;
}