package com.zhyar;

public class Sizes {
    private String size;

    public Sizes(String size) {
        this.size = size;
    }
}
