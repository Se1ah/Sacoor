package com.zhyar.view;

public enum Role {
    Admin,
    Employee
}
