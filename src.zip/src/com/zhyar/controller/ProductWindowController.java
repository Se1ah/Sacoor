package com.zhyar.controller;

import com.zhyar.EmailManager;
import com.zhyar.Products;
import com.zhyar.view.ViewFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ProductWindowController extends BaseController implements Initializable {

    @FXML
    private TableView<Products> productList;

    @FXML
    private TableColumn<Products, Integer> col_id;

    @FXML
    private TableColumn<Products, String> col_product;

    @FXML
    private TableColumn<Products, String> col_barcode;

    @FXML
    private TableColumn<Products, Integer> col_stock;

    @FXML
    private TableColumn<Products, Integer> col_color;

    @FXML
    private TableColumn<Products, Integer> col_size;

    @FXML
    private TextField txt_id;

    @FXML
    private TextField txt_product;

    @FXML
    private TextField txt_barcode;

    @FXML
    private TextField txt_stock;

    @FXML
    private TextField txt_color;

    @FXML
    private TextField txt_size;


    public ProductWindowController(EmailManager emailManager, ViewFactory viewFactory, String fxmlName) {
        super(emailManager, viewFactory, fxmlName);
    }
    int index = -1;
    @FXML
    void getSelected(MouseEvent event){
        index = productList.getSelectionModel().getSelectedIndex();
        if (index <= -1){
            return;
        }
        txt_id.setText(col_id.getCellData(index).toString());
        txt_product.setText(col_product.getCellData(index));
        txt_barcode.setText(col_barcode.getCellData(index));
        txt_stock.setText(col_stock.getCellData(index).toString());
        txt_color.setText(col_color.getCellData(index).toString());
        txt_size.setText(col_size.getCellData(index).toString());
    }

    @FXML
    void addButtonAction() {
        try{

            String productName = txt_product.getText();
            String barcode = txt_barcode.getText();
            int stock = Integer.parseInt(txt_stock.getText());
            String color = txt_color.getText();
            String size = txt_size.getText();

            conn = DBConnection.getConnection();
            pst = conn.prepareStatement("SELECT name FROM products WHERE name = ?");
            pst.setString(1, txt_product.toString());
            rs = pst.executeQuery();

            if(rs.isBeforeFirst()) {
                System.out.println("product empty");
            }
            else{
                String sql = "INSERT INTO products(name, barcode, stock, color, size) VALUES(?,?,?,?,?)";
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

                ps.setString(1, productName);
                ps.setString(1, barcode);
                ps.setInt(1, stock);
                ps.setString(1, color);
                ps.setString(1, size);
                ps.execute();
                UpdateTable();
            }
        }catch (SQLException throwables){
            System.out.println(throwables);
        }
    }

    @FXML
    void deleteButtonAction() {
        conn = DBConnection.getConnection();
        String sql = "DELETE FROM products WHERE id = ?::integer";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_id.getText());
            pst.execute();
            UpdateTable();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @FXML
    void updateButtonAction() {
        try {
            conn = DBConnection.getConnection();
            String value1 = txt_id.getText();
            String value2 = txt_product.getText();
            String value3 = txt_barcode.getText();
            int value4 = Integer.parseInt(txt_stock.getText());
            int value5 = Integer.parseInt(txt_color.getText());
            int value6 = Integer.parseInt(txt_size.getText());

            String sql = "UPDATE products SET name= '"+value2+"', barcode= '"+value3+"', stock = '"+value4+"', " +
                    "color_id = '"+value5+"', size_id= '"+value6+"' where id='"+value1+"'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            UpdateTable();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        col_id.setCellValueFactory(new PropertyValueFactory<Products, Integer>("id"));
        col_product.setCellValueFactory(new PropertyValueFactory<Products, String>("name"));
        col_barcode.setCellValueFactory(new PropertyValueFactory<Products, String>("barcode"));
        col_stock.setCellValueFactory(new PropertyValueFactory<Products, Integer>("stock"));
        col_color.setCellValueFactory(new PropertyValueFactory<Products, Integer>("color_id"));
        col_size.setCellValueFactory(new PropertyValueFactory<Products, Integer>("size_id"));

        listM = getUsersData();
        productList.setItems(listM);
    }

    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Products,Integer>("id"));
        col_product.setCellValueFactory(new PropertyValueFactory<Products,String>("name"));
        col_barcode.setCellValueFactory(new PropertyValueFactory<Products,String>("barcode"));
        col_stock.setCellValueFactory(new PropertyValueFactory<Products,Integer>("stock"));
        col_color.setCellValueFactory(new PropertyValueFactory<Products,Integer>("color_id"));
        col_size.setCellValueFactory(new PropertyValueFactory<Products,Integer>("size_id"));

        listM = getUsersData();
        productList.setItems(listM);
    }

    public ObservableList<Products> getUsersData(){
        Connection conn = DBConnection.getConnection();
        ObservableList<Products> list = FXCollections.observableArrayList();
        try {
            assert conn != null;
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM products");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Products(Integer.parseInt(rs.getString("id")),rs.getString("name"), rs.getString("barcode"),
                        Integer.parseInt(rs.getString("stock")), Double.parseDouble(rs.getString("price")),Integer.parseInt(rs.getString("color_id")), Integer.parseInt(rs.getString("size_id"))));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return list;
    }

    ObservableList<Products> listM;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
}
