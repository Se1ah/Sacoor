package com.zhyar;

public class EmailManager {
}
