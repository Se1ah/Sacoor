package com.zhyar;

public class Colors {
    private String color;

    public Colors(String color) {
        this.color = color;
    }
}
