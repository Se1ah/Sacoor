package com.zhyar;

public class Suppliers {
    private Integer id;
    private String supplier;

    public Suppliers(Integer id, String supplier) {
        this.id = id;
        this.supplier = supplier;
    }
}
